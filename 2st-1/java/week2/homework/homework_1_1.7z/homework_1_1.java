public class homework_1_1 {
    public static void main(String[] args) {
        System.out.println("蘇泓叡");
        System.out.println("C112156233");
    }
}
