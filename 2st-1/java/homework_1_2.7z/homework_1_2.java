public class homework_1_2 {
    public static void main(String[] args) {
        String id = "C112156233";
        String name = "蘇泓叡";
        int age = 28;
        char sex = '男';
        System.out.printf("%s 同學你好\n你的學號是%s\n你的年齡是%d歲\n你目前的性別是%c性\n", name, id, age, sex);
    }
}
