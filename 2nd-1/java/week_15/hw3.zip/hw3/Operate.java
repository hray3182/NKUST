public interface Operate {
    void operate();
}