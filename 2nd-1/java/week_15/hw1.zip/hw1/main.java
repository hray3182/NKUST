public class main {
    public static void main(String[] args) {
        Bird b = new Bird("鸚鵡", "紅色");
        Plane p = new Plane("波音747", 500);
        b.fly();
        p.fly();
    }
}