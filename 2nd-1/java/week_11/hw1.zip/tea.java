public class tea extends drink {
    private String color;
    private int cc;

    public String getColor(){
        return this.color;
    }

    public void setColor(String color){
        this.color = color;
    }

    public int getCc(){
        return this.cc;
    }

    public void setCc(int cc){
        this.cc = cc;
    }
}
