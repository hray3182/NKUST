public class main {
    public static void main(String[] args){
    Vehicle v1 = new Vehicle();
    System.out.println(v1.toString());
    }
}
