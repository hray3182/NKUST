total = 0
for i in range(100):
    total += i+1
print(total)

