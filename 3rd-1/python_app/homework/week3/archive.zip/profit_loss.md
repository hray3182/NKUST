# 盈數與虧數

建立一個函數處理 user input 並確認類型轉換與>0

建立一個 array, 記錄 user input 的因數

建立一個 sum 變數，將 factors 加總

最後 sum 比較 user input, 決定輸出
